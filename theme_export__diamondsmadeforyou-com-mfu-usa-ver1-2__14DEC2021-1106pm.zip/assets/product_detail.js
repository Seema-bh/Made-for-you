// var checkd = new Array();
// $('.swatch-element').each(function(){
//   checkd = $("input[type=radio]").attr('checked',true);
//   checkedValues = checkd.attr("value");
//   $("#swtach-main").text(checkedValues);
//   console.log("test2", checkd);     
//   console.log("test1", checkedValues);     
// });  
// $('.swatch-element').on("change", function () {
//     checkd = $("#swatch-element input[type=radio]:checked");
//     checkedValues = checkd.attr("value");
//     $("#swtach-main").text(checkedValues);
//     // Hides the content
//     $('#swatches-dropdown').slideUp("slow");
//     $('#swtach-main').removeAttr( "class" );
    
//     console.log("Checked", checkedValues);                
// }); 

// // code to show content
// $("#swtach-main").click(function(){
//     $("#swatches-dropdown").toggle();    
// });
// $(window).mouseup(function(){
//     $('#swatches-dropdown').slideUp("slow");
// });
